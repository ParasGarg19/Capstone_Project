"""Plot candidate-model predictions against a seasonal-naive baseline on the same holdout."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import mean_absolute_error

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.train import add_features

def main():
    df = add_features(pd.read_csv(ROOT / "data" / "revenue.csv"))
    dates = sorted(df["date"].unique())
    cutoff = dates[-6]
    train, test = df[df.date < cutoff].copy(), df[df.date >= cutoff].copy()
    features = ["country", "year", "month", "quarter", "month_sin", "month_cos"]
    pre = ColumnTransformer([
        ("country", OneHotEncoder(handle_unknown="ignore"), ["country"]),
        ("numeric", StandardScaler(), [c for c in features if c != "country"])
    ])
    model = Pipeline([("preprocess", pre), ("model", RandomForestRegressor(
        n_estimators=250, max_depth=8, random_state=17))])
    model.fit(train[features], train.revenue)
    test["model_prediction"] = np.maximum(0, model.predict(test[features]))
    history = df[["country", "date", "revenue"]].copy()
    history["date"] = pd.to_datetime(history["date"])
    lookup = {(r.country, r.date): r.revenue for r in history.itertuples()}
    def baseline(row):
        d = pd.Timestamp(row.date) - pd.DateOffset(years=1)
        return lookup.get((row.country, d), np.nan)
    test["seasonal_naive"] = test.apply(baseline, axis=1)
    test = test.dropna(subset=["seasonal_naive"])
    scores = {"Random Forest": mean_absolute_error(test.revenue, test.model_prediction),
              "Seasonal naive (same month last year)": mean_absolute_error(test.revenue, test.seasonal_naive)}
    out = ROOT / "reports" / "figures"
    out.mkdir(parents=True, exist_ok=True)
    pd.Series(scores).plot(kind="bar", title="Holdout MAE: model vs baseline")
    plt.ylabel("Mean Absolute Error (lower is better)")
    plt.tight_layout()
    plt.savefig(out / "model_vs_baseline.png")
    plt.close()
    print(scores)
    print(f"Saved {out / 'model_vs_baseline.png'}")
if __name__ == "__main__":
    main()
