import logging
import os
from pathlib import Path
from datetime import datetime, timezone

import joblib
import pandas as pd
from flask import Flask, jsonify, request

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = Path(os.getenv("MODEL_PATH", BASE_DIR / "artifacts" / "model.joblib"))
LOG_PATH = Path(os.getenv("LOG_PATH", BASE_DIR / "logs" / "api.log"))
METRICS_PATH = Path(os.getenv("METRICS_PATH", BASE_DIR / "logs" / "metrics.jsonl"))

def configure_logging():
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("forecast_api")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    handler = logging.FileHandler(LOG_PATH)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)
    logger.propagate = False
    return logger

def create_app(model_path=None, log_path=None, metrics_path=None, model=None):
    """Application factory; paths/model can be overridden for isolated tests."""
    global LOG_PATH, METRICS_PATH
    if log_path is not None:
        LOG_PATH = Path(log_path)
    if metrics_path is not None:
        METRICS_PATH = Path(metrics_path)
    logger = configure_logging()
    resolved_model_path = Path(model_path) if model_path else MODEL_PATH

    if model is None and resolved_model_path.exists():
        model = joblib.load(resolved_model_path)

    app = Flask(__name__)
    app.config["FORECAST_MODEL"] = model
    app.config["MODEL_PATH"] = str(resolved_model_path)

    def record_metric(payload):
        METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)
        with METRICS_PATH.open("a", encoding="utf-8") as f:
            import json
            f.write(json.dumps(payload) + "\n")

    @app.get("/health")
    def health():
        return jsonify({"status": "ok", "model_loaded": app.config["FORECAST_MODEL"] is not None})

    @app.get("/metrics")
    def metrics():
        """Lightweight operational metrics: request counts, errors, latency."""
        import json
        path = METRICS_PATH
        rows = []
        if path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return jsonify({
            "record_count": len(rows),
            "prediction_requests": sum(r.get("event") == "prediction" for r in rows),
            "errors": sum(r.get("event") == "error" for r in rows),
            "avg_latency_ms": round(
                sum(r.get("latency_ms", 0) for r in rows) / max(1, len(rows)), 3
            ) if rows else 0.0
        })

    @app.post("/predict")
    def predict():
        started = datetime.now(timezone.utc).timestamp()
        try:
            payload = request.get_json(silent=True) or {}
            country = payload.get("country")
            target_date = payload.get("target_date")
            if not isinstance(country, str) or not country.strip():
                raise ValueError("'country' must be a non-empty string")
            if not isinstance(target_date, str):
                raise ValueError("'target_date' must be a string in YYYY-MM-DD format")
            try:
                date = pd.Timestamp(target_date)
            except Exception as exc:
                raise ValueError("'target_date' must be a valid date in YYYY-MM-DD format") from exc
            if date.strftime("%Y-%m-%d") != target_date:
                raise ValueError("'target_date' must use YYYY-MM-DD format")

            model = app.config["FORECAST_MODEL"]
            if model is None:
                return jsonify({"error": "Model not found. Run scripts/train.py first."}), 503

            frame = pd.DataFrame([{
                "country": country.strip(),
                "year": date.year,
                "month": date.month,
                "quarter": date.quarter,
                "month_sin": __import__("math").sin(2 * __import__("math").pi * date.month / 12),
                "month_cos": __import__("math").cos(2 * __import__("math").pi * date.month / 12),
            }])
            prediction = float(model.predict(frame)[0])
            prediction = max(0.0, prediction)
            elapsed = (datetime.now(timezone.utc).timestamp() - started) * 1000
            record_metric({"event": "prediction", "country": country.strip(),
                           "target_date": target_date, "latency_ms": elapsed,
                           "timestamp": datetime.now(timezone.utc).isoformat()})
            logger.info("prediction country=%s target_date=%s latency_ms=%.2f",
                        country.strip(), target_date, elapsed)
            return jsonify({"country": country.strip(), "target_date": target_date,
                            "predicted_revenue": round(prediction, 2), "currency": "USD"})
        except ValueError as exc:
            elapsed = (datetime.now(timezone.utc).timestamp() - started) * 1000
            record_metric({"event": "error", "latency_ms": elapsed,
                           "timestamp": datetime.now(timezone.utc).isoformat(),
                           "message": str(exc)})
            logger.warning("invalid prediction request: %s", exc)
            return jsonify({"error": str(exc)}), 400
        except Exception:
            elapsed = (datetime.now(timezone.utc).timestamp() - started) * 1000
            record_metric({"event": "error", "latency_ms": elapsed,
                           "timestamp": datetime.now(timezone.utc).isoformat(),
                           "message": "internal prediction error"})
            logger.exception("prediction failed")
            return jsonify({"error": "Internal prediction error"}), 500

    @app.post("/predict/all")
    def predict_all():
        """Return predictions for every country known to the trained model."""
        model = app.config["FORECAST_MODEL"]
        if model is None:
            return jsonify({"error": "Model not found. Run scripts/train.py first."}), 503
        payload = request.get_json(silent=True) or {}
        target_date = payload.get("target_date")
        if not isinstance(target_date, str):
            return jsonify({"error": "'target_date' must be a string in YYYY-MM-DD format"}), 400
        try:
            date = pd.Timestamp(target_date)
            if date.strftime("%Y-%m-%d") != target_date:
                raise ValueError()
        except Exception:
            return jsonify({"error": "'target_date' must use YYYY-MM-DD format"}), 400
        countries = getattr(model, "forecast_countries_", None)
        if not countries:
            return jsonify({"error": "Model does not expose its country list"}), 500
        results = []
        for country in countries:
            with app.test_request_context():
                import math
                frame = pd.DataFrame([{"country": country, "year": date.year,
                    "month": date.month, "quarter": date.quarter,
                    "month_sin": math.sin(2 * math.pi * date.month / 12),
                    "month_cos": math.cos(2 * math.pi * date.month / 12)}])
                results.append({"country": country,
                    "predicted_revenue": round(max(0.0, float(model.predict(frame)[0])), 2),
                    "currency": "USD"})
        return jsonify({"target_date": target_date, "predictions": results})

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))
