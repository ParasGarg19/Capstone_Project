# Country Revenue Forecasting API

A reproducible demonstration project for monthly country-level revenue forecasting. It includes a Flask API, deterministic sample-data ingestion, EDA plots, candidate-model comparison, automated tests, request logging, operational metrics, and Docker packaging.

> **Data disclaimer:** The included data generator creates synthetic data for demonstration. Model metrics are not evidence of real-world forecasting accuracy. Replace it with approved historical revenue data before using predictions for business decisions.

## Quick start (Python)

Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
python scripts/ingest_data.py
python scripts/eda.py
python scripts/train.py
python scripts/compare_baseline.py
python -m pytest -q
python app.py
```

## API examples

Specific country:
```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"country":"India","target_date":"2026-03-01"}'
```

All countries:
```bash
curl -X POST http://localhost:5000/predict/all \
  -H "Content-Type: application/json" \
  -d '{"target_date":"2026-03-01"}'
```

Health and operational metrics:
- `GET /health` — application health and model-load status
- `GET /metrics` — request/error counts and average recorded latency
- `POST /predict` — forecast for one country and target date
- `POST /predict/all` — forecasts for all countries represented in training data

## Docker

```bash
docker compose up --build
```
The image generates sample data and trains a model during build. Then use the same API endpoints at `http://localhost:5000`.

## Peer-review checklist mapping

1. **API tests:** `tests/test_api.py` tests health, valid predictions, validation, and all-country forecasts.
2. **Model tests:** `tests/test_model.py` covers calendar feature engineering; training compares and evaluates model candidates.
3. **Logging tests:** `tests/test_logging.py` verifies successful and invalid requests are logged.
4. **One test command:** `./run_tests.sh` (macOS/Linux) or `run_tests.bat` (Windows); both call pytest.
5. **Performance monitoring:** `GET /metrics` reports request count, error count, and mean request latency. This is basic operational monitoring, not full model-drift monitoring.
6. **Test isolation:** tests inject a fake model and write logs/metrics to pytest temporary directories. They do not load or modify production artifacts.
7. **API behavior:** `/predict` forecasts one country; `/predict/all` returns one forecast per trained country.
8. **Ingestion automation:** `scripts/ingest_data.py` is a CLI script and exposes reusable `build_dataset()`.
9. **Multiple models:** Ridge, Random Forest, and HistGradientBoosting are compared on a chronological holdout using MAE and RMSE.
10. **EDA visualization:** `scripts/eda.py` produces revenue-over-time, revenue-by-country, and revenue-distribution charts.
11. **Containerization:** `Dockerfile` and `docker-compose.yml` package and run the service.
12. **Baseline comparison visualization:** see below.

## Baseline comparison

Run `python scripts/compare_baseline.py` to create `reports/figures/model_vs_baseline.png`. It compares a Random Forest model against a seasonal-naive baseline (same country, same month one year earlier) on the same chronological holdout using MAE. The model-selection script separately compares three candidate models.

## Notes and limitations

- Forecast features are the country and target date (calendar features derived from that date).
- Unknown countries are accepted by the API but may receive less reliable forecasts because the model uses one-hot encoding with unknown categories ignored. For production, validate against supported countries.
- This is a starter repository. Add authentication, rate limiting, secure secret management, structured monitoring/alerting, and real-data validation before production deployment.
