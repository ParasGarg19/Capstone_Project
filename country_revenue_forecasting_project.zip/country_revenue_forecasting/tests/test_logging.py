def test_prediction_is_logged(client, tmp_path):
    client.post("/predict", json={"country": "India", "target_date": "2026-03-01"})
    log_text = (tmp_path / "test.log").read_text()
    assert "prediction country=India" in log_text

def test_invalid_request_is_logged(client, tmp_path):
    client.post("/predict", json={"country": "", "target_date": "2026-03-01"})
    log_text = (tmp_path / "test.log").read_text()
    assert "invalid prediction request" in log_text
