def test_metrics_track_predictions_and_errors(client):
    client.post("/predict", json={"country": "India", "target_date": "2026-03-01"})
    client.post("/predict", json={"country": "", "target_date": "2026-03-01"})
    response = client.get("/metrics")
    assert response.status_code == 200
    assert response.json["prediction_requests"] == 1
    assert response.json["errors"] == 1
    assert response.json["avg_latency_ms"] >= 0
