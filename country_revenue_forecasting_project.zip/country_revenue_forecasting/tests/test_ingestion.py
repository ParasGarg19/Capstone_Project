from scripts.ingest_data import build_dataset

def test_ingestion_dataset_schema_and_reproducibility():
    a = build_dataset("2024-01-01", "2024-03-01", seed=5)
    b = build_dataset("2024-01-01", "2024-03-01", seed=5)
    assert list(a.columns) == ["date", "country", "revenue"]
    assert len(a) == 15
    assert a.equals(b)
    assert (a["revenue"] > 0).all()
