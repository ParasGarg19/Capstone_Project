def test_health_reports_model_loaded(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json["model_loaded"] is True

def test_predict_specific_country(client):
    response = client.post("/predict", json={"country": "India", "target_date": "2026-03-01"})
    assert response.status_code == 200
    assert response.json["country"] == "India"
    assert response.json["predicted_revenue"] == 1234.5

def test_predict_rejects_missing_country(client):
    response = client.post("/predict", json={"target_date": "2026-03-01"})
    assert response.status_code == 400

def test_predict_rejects_bad_date(client):
    response = client.post("/predict", json={"country": "India", "target_date": "March 2026"})
    assert response.status_code == 400

def test_predict_all_countries(client):
    response = client.post("/predict/all", json={"target_date": "2026-03-01"})
    assert response.status_code == 200
    assert {x["country"] for x in response.json["predictions"]} == {"India", "Australia"}
