import math
import pytest
from app import create_app

class FakeModel:
    forecast_countries_ = ["Australia", "India"]
    def predict(self, frame):
        return [1234.5 for _ in range(len(frame))]

@pytest.fixture
def client(tmp_path):
    app = create_app(model=FakeModel(), log_path=tmp_path/"test.log",
                     metrics_path=tmp_path/"metrics.jsonl")
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client
