"""Generate a reproducible example dataset. Replace with a real source connector as needed."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd

COUNTRIES = ["India", "Australia", "United Kingdom", "United States", "Canada"]

def build_dataset(start="2021-01-01", end="2025-12-01", seed=17):
    rng = np.random.default_rng(seed)
    dates = pd.date_range(start=start, end=end, freq="MS")
    rows = []
    bases = {"India": 18000, "Australia": 12500, "United Kingdom": 21000,
             "United States": 35000, "Canada": 14500}
    for country in COUNTRIES:
        base = bases[country]
        for i, date in enumerate(dates):
            seasonality = 1 + 0.12 * np.sin(2 * np.pi * date.month / 12)
            trend = 1 + 0.012 * i
            noise = rng.normal(0, 0.055)
            revenue = max(100, base * seasonality * trend * (1 + noise))
            rows.append({"date": date.strftime("%Y-%m-%d"), "country": country,
                         "revenue": round(revenue, 2)})
    return pd.DataFrame(rows)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="data/revenue.csv")
    parser.add_argument("--start", default="2021-01-01")
    parser.add_argument("--end", default="2025-12-01")
    args = parser.parse_args()
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    build_dataset(args.start, args.end).to_csv(output, index=False)
    print(f"Wrote {output}")

if __name__ == "__main__":
    main()
