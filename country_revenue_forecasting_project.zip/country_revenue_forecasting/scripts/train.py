"""Compare candidate models and save the best one using a chronological holdout."""
from pathlib import Path
import json
import math
import sys
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
DATA_PATH = ROOT / "data" / "revenue.csv"
ARTIFACT_DIR = ROOT / "artifacts"
RESULTS_DIR = ROOT / "reports"

def add_features(df):
    out = df.copy()
    dates = pd.to_datetime(out["date"])
    out["year"] = dates.dt.year
    out["month"] = dates.dt.month
    out["quarter"] = dates.dt.quarter
    out["month_sin"] = np.sin(2 * np.pi * out["month"] / 12)
    out["month_cos"] = np.cos(2 * np.pi * out["month"] / 12)
    return out

def main():
    df = pd.read_csv(DATA_PATH)
    df = add_features(df).sort_values("date")
    features = ["country", "year", "month", "quarter", "month_sin", "month_cos"]
    cutoff = df["date"].sort_values().unique()[-6]
    train, test = df[df["date"] < cutoff], df[df["date"] >= cutoff]
    categorical = ["country"]
    numeric = [c for c in features if c not in categorical]
    pre = ColumnTransformer([
        ("country", OneHotEncoder(handle_unknown="ignore"), categorical),
        ("numeric", StandardScaler(), numeric)
    ])
    candidates = {
        "ridge": Ridge(alpha=1.0),
        "random_forest": RandomForestRegressor(n_estimators=250, max_depth=8, random_state=17),
        "hist_gradient_boosting": HistGradientBoostingRegressor(max_iter=150, random_state=17)
    }
    results = []
    best = None
    for name, estimator in candidates.items():
        pipe = Pipeline([("preprocess", pre), ("model", estimator)])
        pipe.fit(train[features], train["revenue"])
        pred = np.maximum(0, pipe.predict(test[features]))
        mae = mean_absolute_error(test["revenue"], pred)
        rmse = math.sqrt(mean_squared_error(test["revenue"], pred))
        results.append({"model": name, "mae": round(float(mae), 3), "rmse": round(float(rmse), 3)})
        if best is None or mae < best[0]:
            best = (mae, name, pipe)
    best[2].forecast_countries_ = sorted(df["country"].unique().tolist())
    ARTIFACT_DIR.mkdir(exist_ok=True)
    RESULTS_DIR.mkdir(exist_ok=True)
    joblib.dump(best[2], ARTIFACT_DIR / "model.joblib")
    (RESULTS_DIR / "model_comparison.json").write_text(json.dumps(results, indent=2))
    print("Model comparison:")
    for row in results:
        print(f"  {row['model']}: MAE={row['mae']:.2f}, RMSE={row['rmse']:.2f}")
    print(f"Selected: {best[1]} (lowest holdout MAE)")
    print(f"Saved model to {ARTIFACT_DIR / 'model.joblib'}")

if __name__ == "__main__":
    main()
