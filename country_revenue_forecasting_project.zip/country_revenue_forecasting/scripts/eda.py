"""Exploratory data analysis plots."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
def main():
    df = pd.read_csv(ROOT / "data" / "revenue.csv", parse_dates=["date"])
    out = ROOT / "reports" / "figures"
    out.mkdir(parents=True, exist_ok=True)
    df.groupby("date", as_index=False)["revenue"].sum().plot(x="date", y="revenue",
        title="Total monthly revenue across countries", legend=False)
    plt.ylabel("Revenue (USD)"); plt.tight_layout(); plt.savefig(out / "monthly_revenue.png"); plt.close()
    df.groupby("country")["revenue"].mean().sort_values().plot(kind="bar",
        title="Average monthly revenue by country")
    plt.ylabel("Revenue (USD)"); plt.tight_layout(); plt.savefig(out / "revenue_by_country.png"); plt.close()
    df["revenue"].plot(kind="hist", bins=25, title="Revenue distribution")
    plt.xlabel("Revenue (USD)"); plt.tight_layout(); plt.savefig(out / "revenue_distribution.png"); plt.close()
    print(f"Saved EDA plots to {out}")
if __name__ == "__main__":
    main()
