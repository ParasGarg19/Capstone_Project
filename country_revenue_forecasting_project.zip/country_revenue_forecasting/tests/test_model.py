import pandas as pd
from scripts.train import add_features

def test_feature_engineering_adds_calendar_features():
    frame = add_features(pd.DataFrame([{"date": "2025-01-01", "country": "India", "revenue": 10}]))
    assert {"year", "month", "quarter", "month_sin", "month_cos"} <= set(frame.columns)
    assert frame.iloc[0]["year"] == 2025
    assert frame.iloc[0]["month"] == 1
